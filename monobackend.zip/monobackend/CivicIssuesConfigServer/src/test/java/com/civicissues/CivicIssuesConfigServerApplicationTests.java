package com.civicissues;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CivicIssuesConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.attachment.service;

public class AttachmentImpl implements AttachmentInterface {

}

package com.attachment.exception;

public class CustomException {

}

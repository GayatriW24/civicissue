package com.attachment.service;

public interface AttachmentInterface {

}

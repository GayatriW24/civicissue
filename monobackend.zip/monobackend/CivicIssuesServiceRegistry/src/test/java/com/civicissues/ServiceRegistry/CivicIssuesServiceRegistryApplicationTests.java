package com.civicissues.ServiceRegistry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CivicIssuesServiceRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}

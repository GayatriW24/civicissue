package com.notification.async;

public class RabbitConfig {

}

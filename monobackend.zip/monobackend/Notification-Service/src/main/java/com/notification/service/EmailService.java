package com.notification.service;

public class EmailService {

}

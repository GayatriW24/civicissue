package com.async.events;

public class ComplaintEvent {

}

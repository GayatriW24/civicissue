package com.civicissues.dto;

import java.util.List;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CreateComplaintRequest {

    @NotBlank
    private String title;

    @NotBlank
    private String description;

    @NotNull
    private Long departmentId;

    @NotNull
    private Long categoryId;

    private List<String> attachmentUrls;
}

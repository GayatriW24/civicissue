package com.civicissues.entity;

public enum UserStatus {
    ACTIVE,
    BLOCKED,
    PENDING_VERIFICATION
}


package com.civicissues.exceptions;


public class ResourceNotFoundException extends Exception {
 
	ResourceNotFoundException(String msg){
		super(msg);
	}
	
	
}

package com.civicissues.services;



import java.time.LocalDateTime;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.civicissues.dto.ComplaintResponse;
import com.civicissues.dto.CreateComplaintRequest;
import com.civicissues.entity.Category;
import com.civicissues.entity.Complaint;
import com.civicissues.entity.ComplaintStatus;
import com.civicissues.entity.Department;
import com.civicissues.entity.User;
import com.civicissues.repository.CategoryRepository;
import com.civicissues.repository.ComplaintRepository;
import com.civicissues.repository.DepartmentRepository;
import com.civicissues.repository.UserRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ComplaintServiceImpl implements ComplaintService {

    private final ComplaintRepository complaintRepository;
    private final UserRepository userRepository;
    private final DepartmentRepository departmentRepository;
    private final CategoryRepository categoryRepository;

    @Override
    public ComplaintResponse createComplaint(CreateComplaintRequest request, String userEmail) {

        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new RuntimeException("user not found"));

        Department department = departmentRepository.findById(request.getDepartmentId())
                .orElseThrow(() -> new RuntimeException("department not found"));

        Category category = categoryRepository.findById(request.getCategoryId())
                .orElseThrow(() -> new RuntimeException("category not found"));

        if (!category.getDepartment().getId().equals(department.getId())) {
            throw new RuntimeException("category does not belong to department");
        }

        Complaint complaint = new Complaint();
        complaint.setTitle(request.getTitle());
        complaint.setDescription(request.getDescription());
        complaint.setUser(user);
        complaint.setDepartment(department);
        complaint.setCategory(category);
        complaint.setAttachmentUrls(request.getAttachmentUrls());

        return mapToResponse(complaintRepository.save(complaint));
    }

    @Override
    public Page<ComplaintResponse> getMyComplaints(String userEmail, Pageable pageable) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new RuntimeException("user not found"));

        return complaintRepository
                .findByUserId(user.getId(), pageable)
                .map(this::mapToResponse);
    }

    @Override
    public void updateStatus(Long complaintId, String status) {
        Complaint complaint = complaintRepository.findById(complaintId)
                .orElseThrow(() -> new RuntimeException("complaint not found"));

        ComplaintStatus newStatus = ComplaintStatus.valueOf(status);

        complaint.setStatus(newStatus);

        if (newStatus == ComplaintStatus.RESOLVED) {
            complaint.setResolvedAt(LocalDateTime.now());
        }

        complaintRepository.save(complaint);
    }

    private ComplaintResponse mapToResponse(Complaint c) {
        ComplaintResponse r = new ComplaintResponse();
        r.setId(c.getId());
        r.setTitle(c.getTitle());
        r.setDescription(c.getDescription());
        r.setStatus(c.getStatus());
        r.setDepartment(c.getDepartment().getName());
        r.setCategory(c.getCategory().getName());
        r.setCreatedOn(c.getCreatedOn());
        r.setAttachmentUrls(c.getAttachmentUrls());
        return r;
    }
}


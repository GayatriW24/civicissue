package com.civicissues.services;

import org.springframework.stereotype.Service;

import com.civicissues.entity.Complaint;
import com.civicissues.entity.Response;
import com.civicissues.entity.SenderType;
import com.civicissues.repository.ComplaintRepository;
import com.civicissues.repository.ResponseRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ResponseService {

    private final ComplaintRepository complaintRepository;
    private final ResponseRepository responseRepository;

    public Response addResponse(Long complaintId, String message, SenderType type, Long senderId) {

        Complaint complaint = complaintRepository.findById(complaintId).orElseThrow();

        Response r = new Response();
        r.setComplaint(complaint);
        r.setMessage(message);
        r.setSenderType(type);
        r.setSenderId(senderId);

        return responseRepository.save(r);
    }
}


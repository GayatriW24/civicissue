package com.civicissues.dto;

import java.time.LocalDateTime;
import java.util.List;

import com.civicissues.entity.ComplaintStatus;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ComplaintResponse {

    private Long id;
    private String title;
    private String description;
    private ComplaintStatus status;
    private String department;
    private String category;
    private LocalDateTime createdOn;
    private List<String> attachmentUrls;
}

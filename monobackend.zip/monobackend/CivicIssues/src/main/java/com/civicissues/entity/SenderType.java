package com.civicissues.entity;

public enum SenderType {
    CITIZEN,
    ADMIN,
    SYSTEM
}

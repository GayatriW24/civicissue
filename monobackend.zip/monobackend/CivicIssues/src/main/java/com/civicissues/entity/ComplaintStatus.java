package com.civicissues.entity;

public enum ComplaintStatus {
    PENDING,
    ASSIGNED,
    IN_PROGRESS,
    RESOLVED,
    REJECTED
}


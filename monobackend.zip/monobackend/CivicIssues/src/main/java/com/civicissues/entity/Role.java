package com.civicissues.entity;

public enum Role {
    CITIZEN,
    ADMIN,
    SUPERADMIN
}

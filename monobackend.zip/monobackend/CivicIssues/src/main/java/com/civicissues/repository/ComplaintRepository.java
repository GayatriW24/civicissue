package com.civicissues.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import com.civicissues.entity.Complaint;
import com.civicissues.entity.ComplaintStatus;

public interface ComplaintRepository extends JpaRepository<Complaint, Long> {
    List<Complaint> findByUserId(Long userId);
    List<Complaint> findByStatus(ComplaintStatus status);
    Page<Complaint> findByUserId(Long userId, Pageable pageable);

    Page<Complaint> findByDepartmentId(Long departmentId, Pageable pageable);
}


package com.civicissues.exceptions;

public class ResourceAlreadyExisted extends Exception{
 ResourceAlreadyExisted(String msg){
	 super(msg);
 }
}

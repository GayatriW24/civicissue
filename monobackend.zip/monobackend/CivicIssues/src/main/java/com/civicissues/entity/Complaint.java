package com.civicissues.entity;

import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "complaints")
@Getter
@Setter
public class Complaint extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;
    private String description;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne
    @JoinColumn(name = "department_id")
    private Department department;

    @ManyToOne
    @JoinColumn(name = "category_id")
    private Category category;

    @Enumerated(EnumType.STRING)
    private ComplaintStatus status = ComplaintStatus.PENDING;
    
    @ElementCollection
    @CollectionTable(
        name = "complaint_attachments",
        joinColumns = @JoinColumn(name = "complaint_id")
    )
    
    @Column(name = "attachment_url")
    private List<String> attachmentUrls;
    

    @OneToMany(mappedBy = "complaint", cascade = CascadeType.ALL)
    private List<Response> responses;

    @OneToOne(mappedBy = "complaint", cascade = CascadeType.ALL)
    private Feedback feedback;

    private LocalDateTime resolvedAt;
}

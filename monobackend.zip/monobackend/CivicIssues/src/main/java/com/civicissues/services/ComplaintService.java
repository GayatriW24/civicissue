package com.civicissues.services;




import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.civicissues.dto.CreateComplaintRequest;
import com.civicissues.dto.ComplaintResponse;

public interface ComplaintService {

    ComplaintResponse createComplaint(CreateComplaintRequest request, String userEmail);

    Page<ComplaintResponse> getMyComplaints(String userEmail, Pageable pageable);

    void updateStatus(Long complaintId, String status);
}

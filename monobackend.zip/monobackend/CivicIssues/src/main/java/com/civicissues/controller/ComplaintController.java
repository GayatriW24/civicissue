package com.civicissues.controller;



import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.civicissues.dto.ComplaintResponse;
import com.civicissues.dto.CreateComplaintRequest;
import com.civicissues.services.ComplaintService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/complaints")
@RequiredArgsConstructor
public class ComplaintController {

    private final ComplaintService complaintService;

    @PostMapping
    public ComplaintResponse create(
            @Validated @RequestBody CreateComplaintRequest request,
            Authentication auth) {
        return complaintService.createComplaint(request, auth.getName());
    }

    @GetMapping("/my")
    public Page<ComplaintResponse> myComplaints(
            Authentication auth,
            Pageable pageable) {
        return complaintService.getMyComplaints(auth.getName(), pageable);
    }

    @PatchMapping("/{id}/status")
    public void updateStatus(
            @PathVariable Long id,
            @RequestParam String status) {
        complaintService.updateStatus(id, status);
    }
}

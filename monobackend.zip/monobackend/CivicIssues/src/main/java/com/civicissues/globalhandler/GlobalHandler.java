package com.civicissues.globalhandler;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.civicissues.dto.ApiResponse;
import com.civicissues.exceptions.ResourceAlreadyExisted;
import com.civicissues.exceptions.ResourceNotFoundException;

@RestControllerAdvice
public class GlobalHandler {

	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<?> handleResourceNotFoundException( ResourceNotFoundException e) throws ResourceNotFoundException{
		
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ApiResponse(e.getMessage(),"failure"));
		 
	}
	
	@ExceptionHandler(ResourceAlreadyExisted.class)
	public ResponseEntity<?> handleDuplicateResource(ResourceAlreadyExisted duplicateResource) throws ResourceAlreadyExisted{
		return ResponseEntity.status(HttpStatus.CONFLICT).body(new ApiResponse(duplicateResource.getMessage(), "failure"));
		
	}
	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<?> handleAllException(RuntimeException e) throws RuntimeException{
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ApiResponse(e.getMessage(), "failure"));

	}
	
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<?> handleMethodArgumentNotValidException(MethodArgumentNotValidException e )throws MethodArgumentNotValidException{
		
		List<FieldError> error=e.getFieldErrors();
		Map<String,String> ferrors=error.stream()
				.collect(Collectors.toMap(FieldError::getField, FieldError::getDefaultMessage));
		
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ferrors);
		
	}
}

package com.civicissues;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CivicIssuesApplicationTests {

	@Test
	void contextLoads() {
	}

}
